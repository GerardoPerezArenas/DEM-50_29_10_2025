
package es.altia.flexia.integracion.moduloexterno.melanbide11.vo;

public class DesplegableExternoVO {
    
    private String campoCodigo;
    private String campoValor;

    public String getCampoCodigo() {
        return campoCodigo;
    }

    public void setCampoCodigo(String campoCodigo) {
        this.campoCodigo = campoCodigo;
    }

    public String getCampoValor() {
        return campoValor;
    }

    public void setCampoValor(String campoValor) {
        this.campoValor = campoValor;
    }

    
}
