
package es.altia.flexia.integracion.moduloexterno.melanbide11.vo;

public class DatosTablaDesplegableExtVO {
    
    private String codigoDesplegagle;
    private String tabla;
    private String campoCodigo;
    private String campoValor;

    public String getCodigoDesplegagle() {
        return codigoDesplegagle;
    }

    public void setCodigoDesplegagle(String codigoDesplegagle) {
        this.codigoDesplegagle = codigoDesplegagle;
    }

    public String getTabla() {
        return tabla;
    }

    public void setTabla(String tabla) {
        this.tabla = tabla;
    }

    public String getCampoCodigo() {
        return campoCodigo;
    }

    public void setCampoCodigo(String campoCodigo) {
        this.campoCodigo = campoCodigo;
    }

    public String getCampoValor() {
        return campoValor;
    }

    public void setCampoValor(String campoValor) {
        this.campoValor = campoValor;
    }
    
    
    
}
