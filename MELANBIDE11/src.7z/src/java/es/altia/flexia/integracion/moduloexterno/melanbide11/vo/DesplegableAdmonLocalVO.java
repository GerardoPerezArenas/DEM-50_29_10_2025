
package es.altia.flexia.integracion.moduloexterno.melanbide11.vo;

public class DesplegableAdmonLocalVO {
    
    private String des_cod;
    private String des_val_cod;
    private String des_nom;

    public String getDes_cod() {
        return des_cod;
    }

    public void setDes_cod(String des_cod) {
        this.des_cod = des_cod;
    }

    public String getDes_val_cod() {
        return des_val_cod;
    }

    public void setDes_val_cod(String des_val_cod) {
        this.des_val_cod = des_val_cod;
    }

    public String getDes_nom() {
        return des_nom;
    }

    public void setDes_nom(String des_nom) {
        this.des_nom = des_nom;
    }
    
}
